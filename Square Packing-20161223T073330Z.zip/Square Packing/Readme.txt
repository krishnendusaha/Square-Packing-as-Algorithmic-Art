Source code in src/BTP folder 
Square_packing_final gives square packing using d4 and d8 change variable opt=1/2 to get  d8 and d4 respectively.
Square_euclidean gives square packing using de.
outlines_new holds the input images .
svg_new holds the output svgs.
denomination[] array holds the size of denominations.
set threshold appropriately. 