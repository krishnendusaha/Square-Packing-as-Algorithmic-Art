clear all
close all
%% input
I    = imread('turban.png');    % Original: also test 2.jpg
%% parameters

% meanshift parameter
bw   = 0.1;                % Mean Shift Bandwidth

[Ims2, Nms2] = Ms2(I,bw);                   % Mean Shift (color + spatial)
figure()
imshow(Ims2); title(['MeanShift+Spatial',' : ',num2str(Nms2)]);
imwrite(Ims2,'turban_ms2.png');
